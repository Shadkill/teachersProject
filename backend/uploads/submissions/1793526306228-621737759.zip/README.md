# UltraVanilla+ v1.0

Enhanced vanilla Minecraft shaders. Improves lighting, shadows, and water while keeping the vanilla sky, fog, and clouds you know and love.

## Philosophy
Enhance, don't replace. Vanilla sky, fog, and clouds are untouched. Everything looks like Minecraft, just better.

## Features
- Soft PCF shadows (3 quality tiers)
- Warm golden sunlight, cool blue moonlight
- Warm orange torch light with configurable brightness
- Rain wetness: exposed ground gets dark, reflective, and specular
- Glass and ice fresnel reflections
- Animated water with 4-octave waves and Gerstner displacement
- Water surface reflections and specular highlights
- Underwater caustics
- Thick underwater fog with blue-green tinting
- Subtle god rays (screen-edge fade, rain-aware)
- ACES filmic tone mapping
- Warm day / cool night color grading
- Film grain and vignette
- Wind animation on grass, flowers, and leaves
- 22 configurable settings in Iris menu

## Install
1. Fabric + Iris + Sodium
2. Drop zip into .minecraft/shaderpacks/
3. Select in Video Settings > Shader Packs

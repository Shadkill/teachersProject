#version 120
#include "common.glsl"
varying vec2 tc; varying vec2 lm; varying vec4 co;
uniform sampler2D texture; uniform int worldTime;
void main() {
    vec4 a=texture2D(texture,tc)*co; if(a.a<0.01)discard;
    float d=getDay(worldTime);
    vec3 l=torch(lm.x)+skyAmb(lm.y,d)+ambFloor(d);
    gl_FragData[0]=vec4(a.rgb*l,a.a);
}

#version 120
#include "common.glsl"
varying vec2 tc; varying vec4 co;
void main() {
    tc=(gl_TextureMatrix[0]*gl_MultiTexCoord0).xy; co=gl_Color;
    gl_Position=ftransform();
    gl_Position.xy=shadowDist(gl_Position.xy);
    gl_Position.z*=SSCALE;
}

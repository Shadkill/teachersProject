#version 120
varying vec4 co;
void main() { co=gl_Color; gl_Position=ftransform(); }

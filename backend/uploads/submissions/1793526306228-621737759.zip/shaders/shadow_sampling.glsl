// UltraVanilla+ v1.0 - Shadows
#ifndef SHAD_GLSL
#define SHAD_GLSL
uniform sampler2D shadowtex0;

float shadH(vec4 s) { return step(s.z-0.0008, texture2D(shadowtex0,s.xy).r); }

float shadS(vec4 s) {
    float b=0.0008, sp=0.0005*SHADOW_SOFT, r=0.0;
    r+=step(s.z-b,texture2D(shadowtex0,s.xy+vec2(-0.94,-0.34)*sp).r);
    r+=step(s.z-b,texture2D(shadowtex0,s.xy+vec2( 0.94, 0.34)*sp).r);
    r+=step(s.z-b,texture2D(shadowtex0,s.xy+vec2(-0.34, 0.94)*sp).r);
    r+=step(s.z-b,texture2D(shadowtex0,s.xy+vec2( 0.34,-0.94)*sp).r);
    r+=step(s.z-b,texture2D(shadowtex0,s.xy+vec2(-0.60, 0.58)*sp).r);
    r+=step(s.z-b,texture2D(shadowtex0,s.xy+vec2( 0.60,-0.58)*sp).r);
    r+=step(s.z-b,texture2D(shadowtex0,s.xy+vec2( 0.10, 0.20)*sp).r);
    r+=step(s.z-b,texture2D(shadowtex0,s.xy+vec2(-0.10,-0.20)*sp).r);
    return r/8.0;
}

float shadVS(vec4 s) {
    float b=0.0008, sp=0.001*SHADOW_SOFT, r=0.0;
    r+=step(s.z-b,texture2D(shadowtex0,s.xy+vec2(-0.94,-0.34)*sp).r);
    r+=step(s.z-b,texture2D(shadowtex0,s.xy+vec2( 0.94, 0.34)*sp).r);
    r+=step(s.z-b,texture2D(shadowtex0,s.xy+vec2(-0.34, 0.94)*sp).r);
    r+=step(s.z-b,texture2D(shadowtex0,s.xy+vec2( 0.34,-0.94)*sp).r);
    r+=step(s.z-b,texture2D(shadowtex0,s.xy+vec2(-0.60, 0.58)*sp).r);
    r+=step(s.z-b,texture2D(shadowtex0,s.xy+vec2( 0.60,-0.58)*sp).r);
    r+=step(s.z-b,texture2D(shadowtex0,s.xy+vec2( 0.10, 0.20)*sp).r);
    r+=step(s.z-b,texture2D(shadowtex0,s.xy+vec2(-0.10,-0.20)*sp).r);
    r+=step(s.z-b,texture2D(shadowtex0,s.xy+vec2(-0.80, 0.10)*sp).r);
    r+=step(s.z-b,texture2D(shadowtex0,s.xy+vec2( 0.80,-0.10)*sp).r);
    r+=step(s.z-b,texture2D(shadowtex0,s.xy+vec2( 0.25, 0.75)*sp).r);
    r+=step(s.z-b,texture2D(shadowtex0,s.xy+vec2(-0.25,-0.75)*sp).r);
    return r/12.0;
}

float shad(vec4 s) {
    if(s.x<0.001||s.x>0.999||s.y<0.001||s.y>0.999||s.z<0.0||s.z>1.0) return 1.0;
    #if SHADOW_QUALITY==0
    return shadH(s);
    #elif SHADOW_QUALITY==1
    return shadS(s);
    #else
    return shadVS(s);
    #endif
}
#endif

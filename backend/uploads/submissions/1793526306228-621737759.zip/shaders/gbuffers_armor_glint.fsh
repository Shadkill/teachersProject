#version 120
varying vec2 tc; varying vec4 co;
uniform sampler2D texture;
void main() { gl_FragData[0]=texture2D(texture,tc)*co; }

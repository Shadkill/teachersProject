#version 120
// UltraVanilla+ v1.0 - Terrain
#include "common.glsl"
#include "shadow_sampling.glsl"
varying vec2 tc; varying vec2 lm; varying vec4 co;
varying vec3 nm; varying vec3 vp; varying vec4 sp; varying vec3 wp;
uniform sampler2D texture;
uniform vec3 sunPosition; uniform vec3 moonPosition;
uniform float rainStrength; uniform int worldTime;

void main() {
    vec4 a = texture2D(texture, tc) * co;
    if (a.a < 0.1) discard;
    
    float day = getDay(worldTime);
    float sunset = getSunset(worldTime);
    
    // Light direction
    vec3 ld;
    if (day > 0.01) ld = normalize(sunPosition);
    else ld = normalize(moonPosition);
    
    // Diffuse with soft wrap
    float ndl = max(dot(nm, ld), 0.0);
    float wrap = max((ndl + 0.15) / 1.15, 0.0);
    
    // Shadow
    float sh = shad(sp);
    
    // Sun/moon color
    vec3 sc = sunTint(day, sunset);
    
    // Direct light - sun bright, moon subtle
    vec3 direct = sc * wrap * sh * SUN_STRENGTH * mix(0.35, 1.0, day);
    
    // Lightmap lights
    vec3 tl = torch(lm.x);
    vec3 sl = skyAmb(lm.y, day);
    vec3 amb = ambFloor(day);
    
    // AO from sky lightmap
    float ao = mix(1.0, lm.y, AO * 0.4);
    ao = max(ao, lm.x * 0.5);
    
    // Combine
    vec3 light = (direct + tl + sl + amb) * ao;
    light *= mix(1.0, 0.5, rainStrength);
    
    vec3 lit = a.rgb * light;
    
    // View direction for reflections
    vec3 vd = normalize(-vp);
    float ndv = max(dot(nm, vd), 0.0);
    
    // === Rain wetness ===
    if (rainStrength > 0.01) {
        float up = smoothstep(0.5, 0.9, max(dot(nm, vec3(0.0, 1.0, 0.0)), 0.0));
        float sky = smoothstep(0.6, 0.9, lm.y);
        float wet = up * sky * rainStrength;
        
        if (wet > 0.01) {
            // Darken + slight saturation boost
            lit *= mix(1.0, 0.72, wet * 0.4);
            
            // Wet fresnel sky reflection
            float wf = schlick(ndv, 0.04) * wet;
            vec3 skyRef = vec3(0.3, 0.35, 0.42) * mix(0.3, 1.0, day);
            lit = mix(lit, skyRef, wf * 0.4);
            
            // Wet specular
            vec3 hd = normalize(ld + vd);
            float ws = pow(max(dot(nm, hd), 0.0), 96.0);
            lit += sc * ws * wet * 0.3 * day * sh;
        }
    }
    
    // === Glass/Ice reflections ===
    #if REFLECTIONS == 1
    {
        float origA = texture2D(texture, tc).a * co.a;
        bool glass = (origA < 0.9 && origA > 0.1);
        bool ice = (a.b > a.r * 1.4) && (a.b > a.g * 1.15) && a.b > 0.35;
        
        if (glass || ice) {
            float rf = schlick(ndv, glass ? 0.08 : 0.05);
            vec3 skyR = vec3(0.3, 0.45, 0.7) * mix(0.15, 1.0, day);
            vec3 hd = normalize(ld + vd);
            float spc = pow(max(dot(nm, hd), 0.0), glass ? 300.0 : 200.0);
            lit = mix(lit, skyR, rf * 0.28);
            lit += sc * spc * SPECULAR * rf * mix(0.15, 0.8, day);
        }
    }
    #endif
    
    // Subtle saturation
    float lum = dot(lit, vec3(0.2126, 0.7152, 0.0722));
    lit = mix(vec3(lum), lit, SAT_BOOST);
    
    gl_FragData[0] = vec4(lit, a.a);
}

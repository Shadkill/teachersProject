#version 120
// UltraVanilla+ v1.0 - Composite
// Minimal: god rays + underwater. Vanilla sky/fog/clouds untouched.
#include "common.glsl"
varying vec2 tc;
uniform sampler2D gcolor;
uniform sampler2D depthtex0;
uniform vec3 sunPosition;
uniform float far; uniform float near;
uniform float rainStrength;
uniform int worldTime;
uniform int isEyeInWater;
uniform mat4 gbufferProjection;

float linD(float d) {
    return 2.0*near*far/(far+near-(2.0*d-1.0)*(far-near));
}

// === Underwater fog ===
vec3 uwFog(vec3 c, float dist, float day) {
    vec3 shallow = vec3(0.02, 0.10, 0.20) * (mix(0.4, 1.0, day) + 0.15);
    vec3 deep = vec3(0.005, 0.02, 0.06) * (mix(0.3, 1.0, day) + 0.1);
    float den = UW_FOG * 50.0;
    float f = clamp(1.0 - exp(-dist * den / far), 0.0, 0.98);
    vec3 uc = mix(shallow, deep, f);
    vec3 r = mix(c, uc, f);
    return mix(r, r * vec3(0.3, 0.75, 1.2), 0.25);
}

// === Subtle god rays ===
vec3 rays(vec2 uv, float day) {
    if (day < 0.02 || GODRAYS < 0.01) return vec3(0.0);
    
    vec4 sc = gbufferProjection * vec4(normalize(sunPosition) * far, 1.0);
    if (sc.w <= 0.0) return vec3(0.0);
    vec2 ss = (sc.xy / sc.w) * 0.5 + 0.5;
    
    // Smooth screen edge fade
    float ef = smoothstep(-0.4, 0.1, ss.x) * smoothstep(1.4, 0.9, ss.x)
             * smoothstep(-0.4, 0.1, ss.y) * smoothstep(1.4, 0.9, ss.y);
    if (ef < 0.001) return vec3(0.0);
    
    // 10 radial samples
    vec2 dt = (uv - ss) * (1.0/10.0) * 0.55;
    vec2 sp = uv; float il = 0.0, cd = 1.0;
    float w = 0.03; float dc = 0.93;
    sp-=dt;cd*=dc;il+=step(0.999,texture2D(depthtex0,sp).r)*w*cd;
    sp-=dt;cd*=dc;il+=step(0.999,texture2D(depthtex0,sp).r)*w*cd;
    sp-=dt;cd*=dc;il+=step(0.999,texture2D(depthtex0,sp).r)*w*cd;
    sp-=dt;cd*=dc;il+=step(0.999,texture2D(depthtex0,sp).r)*w*cd;
    sp-=dt;cd*=dc;il+=step(0.999,texture2D(depthtex0,sp).r)*w*cd;
    sp-=dt;cd*=dc;il+=step(0.999,texture2D(depthtex0,sp).r)*w*cd;
    sp-=dt;cd*=dc;il+=step(0.999,texture2D(depthtex0,sp).r)*w*cd;
    sp-=dt;cd*=dc;il+=step(0.999,texture2D(depthtex0,sp).r)*w*cd;
    sp-=dt;cd*=dc;il+=step(0.999,texture2D(depthtex0,sp).r)*w*cd;
    sp-=dt;cd*=dc;il+=step(0.999,texture2D(depthtex0,sp).r)*w*cd;
    il *= 0.15;
    
    // Subtle glow near sun
    float sd = length(ss - uv);
    il += exp(-sd * 6.0) * 0.08;
    
    il *= mix(1.0, 0.03, rainStrength) * ef;
    
    float sunset = getSunset(worldTime);
    vec3 rc = mix(vec3(1.0, 0.88, 0.55), vec3(1.0, 0.5, 0.15), sunset);
    return rc * il * day * GODRAYS;
}

void main() {
    vec3 c = texture2D(gcolor, tc).rgb;
    float depth = texture2D(depthtex0, tc).r;
    float day = getDay(worldTime);
    
    // Underwater fog only
    if (depth < 0.999 && isEyeInWater == 1) {
        c = uwFog(c, linD(depth), day);
    }
    
    // God rays (only above water)
    if (isEyeInWater == 0) {
        c += rays(tc, day);
    }
    
    gl_FragData[0] = vec4(c, 1.0);
}

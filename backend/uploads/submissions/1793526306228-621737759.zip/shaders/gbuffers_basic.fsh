#version 120
varying vec4 co;
void main() { gl_FragData[0]=co; }

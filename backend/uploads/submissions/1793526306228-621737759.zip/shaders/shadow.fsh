#version 120
varying vec2 tc; varying vec4 co;
uniform sampler2D texture;
void main() { vec4 a=texture2D(texture,tc)*co; if(a.a<0.1)discard; gl_FragData[0]=a; }

#version 120
varying vec2 tc; varying vec4 co;
uniform float frameTimeCounter;
void main() {
    tc=(gl_TextureMatrix[0]*gl_MultiTexCoord0).xy; co=gl_Color;
    vec4 p=gl_ModelViewMatrix*gl_Vertex;
    p.x+=sin(p.x*2.0+frameTimeCounter*3.0)*0.01;
    gl_Position=gl_ProjectionMatrix*p;
}

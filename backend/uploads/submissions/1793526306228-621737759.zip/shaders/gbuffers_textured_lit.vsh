#version 120
#include "common.glsl"
varying vec2 tc; varying vec2 lm; varying vec4 co;
void main() {
    tc=(gl_TextureMatrix[0]*gl_MultiTexCoord0).xy;
    lm=(gl_TextureMatrix[1]*gl_MultiTexCoord1).xy;
    co=gl_Color; gl_Position=ftransform();
}

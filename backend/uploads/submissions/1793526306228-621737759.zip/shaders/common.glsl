// UltraVanilla+ v1.0

// === Shadows ===
const int SHADOW_QUALITY = 1;          // [0 1 2]
const float SHADOW_SOFT = 1.0;         // [0.5 0.75 1.0 1.5 2.0]
const float AO = 0.5;                  // [0.0 0.25 0.5 0.75 1.0]

// === Lighting ===
const float SUN_STRENGTH = 0.8;        // [0.4 0.5 0.6 0.7 0.8 0.9 1.0]
const float NIGHT_AMB = 0.5;           // [0.2 0.35 0.5 0.65 0.8]
const float TORCH_BRIGHT = 0.75;       // [0.4 0.5 0.65 0.75 0.9 1.0]

// === Water ===
const float WATER_ALPHA = 0.4;         // [0.15 0.25 0.4 0.55 0.7]
const float WAVES = 0.7;               // [0.2 0.4 0.7 1.0 1.3]
const float WAVE_DETAIL = 1.0;         // [0.5 0.75 1.0 1.5]
const int CAUSTICS = 1;                // [0 1]
const float SPECULAR = 1.0;            // [0.0 0.5 1.0 1.5 2.0]
const float UW_FOG = 0.5;              // [0.2 0.35 0.5 0.7 1.0]
const int REFLECTIONS = 1;             // [0 1]

// === Atmosphere ===
const float SUNSET_STR = 0.6;          // [0.0 0.3 0.6 0.8 1.0]
const float GODRAYS = 0.3;             // [0.0 0.15 0.3 0.5 0.75]

// === Post ===
const float EXPOSURE = 0.9;            // [0.6 0.7 0.8 0.9 1.0 1.1]
const float CONTRAST = 0.2;            // [0.0 0.1 0.2 0.3 0.4]
const float SAT_BOOST = 1.06;          // [0.9 1.0 1.06 1.12 1.2]
const int FILM_GRAIN = 1;              // [0 1]
const float VIGNETTE = 0.12;           // [0.0 0.08 0.12 0.2 0.3]

// === Internal ===
const float SDIST = 0.85;
const float SSCALE = 0.2;

vec2 shadowDist(vec2 p) {
    return p / ((1.0 - SDIST) + length(p) * SDIST);
}

// === Time ===
float getDay(int t) {
    float d = 1.0;
    if (t > 12000 && t <= 13000) d = 1.0 - float(t - 12000) / 1000.0;
    else if (t > 13000 && t <= 23000) d = 0.0;
    else if (t > 23000) d = float(t - 23000) / 1000.0;
    return clamp(d, 0.0, 1.0);
}
float getSunset(int t) {
    float f = 0.0;
    if (t > 11500 && t < 13500) f = 1.0 - abs(float(t - 12500)) / 1000.0;
    else if (t > 22500 || t < 500) {
        float s = float(t > 22500 ? t - 22500 : t + 1500);
        f = 1.0 - abs(s - 1000.0) / 1000.0;
    }
    return clamp(f, 0.0, 1.0);
}

// === Colors ===
vec3 sunTint(float d, float ss) {
    vec3 noon = vec3(0.88, 0.83, 0.66); // Warm golden
    vec3 dusk = vec3(0.95, 0.42, 0.12); // Deep orange
    vec3 moon = vec3(0.10, 0.12, 0.20); // Cool blue
    vec3 c = mix(moon, noon, d);
    return mix(c, dusk, ss * SUNSET_STR * 1.5);
}

vec3 torch(float lm) {
    return vec3(1.0, 0.62, 0.28) * pow(lm, 2.5) * TORCH_BRIGHT;
}

vec3 skyAmb(float lm, float d) {
    vec3 dayA = vec3(0.18, 0.26, 0.44) * d;
    vec3 nightA = vec3(0.04, 0.05, 0.10) * (1.0 - d) * NIGHT_AMB * 2.0;
    return (dayA + nightA) * lm;
}

vec3 ambFloor(float d) {
    vec3 dayF = vec3(0.03, 0.035, 0.05);
    vec3 nightF = vec3(0.015, 0.02, 0.04) * NIGHT_AMB * 2.0;
    return mix(nightF, dayF, d);
}

float schlick(float ndv, float f0) {
    return f0 + (1.0 - f0) * pow(1.0 - ndv, 5.0);
}

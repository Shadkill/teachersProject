#version 120
#include "common.glsl"
varying vec2 tc; varying vec2 lm; varying vec4 co;
varying vec3 nm; varying vec3 vp; varying vec4 sp; varying vec3 wp;
attribute vec4 mc_Entity; attribute vec4 mc_midTexCoord;
uniform mat4 gbufferModelView; uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView; uniform mat4 shadowProjection;
uniform vec3 cameraPosition; uniform float frameTimeCounter;

void main() {
    tc=(gl_TextureMatrix[0]*gl_MultiTexCoord0).xy;
    lm=(gl_TextureMatrix[1]*gl_MultiTexCoord1).xy;
    co=gl_Color;
    nm=normalize(gl_NormalMatrix*gl_Normal);
    
    vec4 v=gbufferModelViewInverse*(gl_ModelViewMatrix*gl_Vertex);
    wp=v.xyz+cameraPosition;
    
    // Gentle wind
    float top=0.0;
    if(mc_Entity.x==31.0||mc_Entity.x==37.0||mc_Entity.x==38.0||mc_Entity.x==175.0)
        top=float(gl_MultiTexCoord0.t<mc_midTexCoord.t);
    if(mc_Entity.x==18.0||mc_Entity.x==161.0) top=1.0;
    if(top>0.5) {
        float w=sin(wp.x*0.5+frameTimeCounter*1.4)*cos(wp.z*0.7+frameTimeCounter*1.1)*0.025;
        if(mc_Entity.x==18.0||mc_Entity.x==161.0) w*=0.35;
        v.x+=w; v.z+=w*0.4;
    }
    
    vp=(gbufferModelView*v).xyz;
    sp=shadowProjection*shadowModelView*v;
    sp.xy=shadowDist(sp.xy); sp.z*=SSCALE;
    sp=sp*0.5+0.5;
    gl_Position=gl_ProjectionMatrix*gbufferModelView*v;
}

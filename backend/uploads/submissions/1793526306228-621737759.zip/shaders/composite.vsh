#version 120
varying vec2 tc;
void main() { tc=(gl_TextureMatrix[0]*gl_MultiTexCoord0).xy; gl_Position=ftransform(); }

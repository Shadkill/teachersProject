#version 120
varying vec2 tc; varying vec4 co;
void main() { tc=(gl_TextureMatrix[0]*gl_MultiTexCoord0).xy; co=gl_Color; gl_Position=ftransform(); }

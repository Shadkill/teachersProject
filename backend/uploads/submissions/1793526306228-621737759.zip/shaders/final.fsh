#version 120
// UltraVanilla+ v1.0 - Final
#include "common.glsl"
varying vec2 tc;
uniform sampler2D gcolor; uniform sampler2D noisetex;
uniform int worldTime; uniform float rainStrength;
uniform float frameTimeCounter; uniform float viewWidth; uniform float viewHeight;

vec3 ACES(vec3 x) {
    return clamp((x*(2.51*x+0.03))/(x*(2.43*x+0.59)+0.14), 0.0, 1.0);
}

void main() {
    vec3 c = texture2D(gcolor, tc).rgb;
    float day = getDay(worldTime);
    float sunset = getSunset(worldTime);
    
    // Exposure - slightly boost night
    float ex = mix(EXPOSURE * 0.92, EXPOSURE, day);
    ex *= mix(1.0, 0.82, rainStrength);
    ex *= mix(1.12, 1.0, day); // Night boost
    c *= ex;
    
    // Tone map
    c = ACES(c);
    
    // Warm day / cool night color grading
    vec3 warm = vec3(1.04, 1.01, 0.94);
    vec3 cool = vec3(0.93, 0.96, 1.07);
    vec3 sunsetT = vec3(1.07, 0.96, 0.86);
    vec3 tint = mix(cool, warm, day);
    tint = mix(tint, sunsetT, sunset * SUNSET_STR * 0.8);
    c *= tint;
    
    // Contrast
    vec3 pre = c;
    c = clamp(c, 0.0, 1.0);
    c = c * c * (3.0 - 2.0 * c);
    c = mix(pre, c, CONTRAST);
    
    // Gamma
    c = pow(c, vec3(1.0 / 2.2));
    
    // Film grain
    #if FILM_GRAIN == 1
    vec2 gu = tc * vec2(viewWidth, viewHeight) / 256.0;
    gu += fract(vec2(frameTimeCounter * 5.7, frameTimeCounter * 3.3));
    float g = (texture2D(noisetex, gu).r - 0.5) * 0.008;
    float lum = dot(c, vec3(0.2126, 0.7152, 0.0722));
    g *= mix(1.0, 0.2, lum);
    c += g;
    #endif
    
    // Vignette
    if (VIGNETTE > 0.01) {
        float vd = length(tc - 0.5);
        c *= 1.0 - smoothstep(0.7, 1.4, vd * 2.0) * VIGNETTE * mix(1.0, 1.5, rainStrength);
    }
    
    gl_FragData[0] = vec4(clamp(c, 0.0, 1.0), 1.0);
}

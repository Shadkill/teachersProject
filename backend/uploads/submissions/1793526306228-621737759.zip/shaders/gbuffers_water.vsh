#version 120
#include "common.glsl"
varying vec2 tc; varying vec2 lm; varying vec4 co;
varying vec3 nm; varying vec3 vp; varying vec3 wp;
varying vec4 sp; varying vec3 tg; varying vec3 bn;
attribute vec4 at_tangent;
uniform mat4 gbufferModelView; uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView; uniform mat4 shadowProjection;
uniform vec3 cameraPosition; uniform float frameTimeCounter;

float wv(vec3 w, float t) {
    float s=WAVES*0.08;
    return (sin(w.x*0.8+t*0.6)*cos(w.z*0.6+t*0.45)*0.5
           +sin(w.x*1.8+w.z*1.2+t*1.2)*0.28
           +sin(w.x*4.0-t*2.0)*cos(w.z*3.5+t*1.5)*0.12*WAVE_DETAIL
           +sin(w.x*7.0+w.z*5.0+t*3.5)*0.06*WAVE_DETAIL)*s;
}

void main() {
    tc=(gl_TextureMatrix[0]*gl_MultiTexCoord0).xy;
    lm=(gl_TextureMatrix[1]*gl_MultiTexCoord1).xy;
    co=gl_Color;
    tg=normalize(gl_NormalMatrix*at_tangent.xyz);
    nm=normalize(gl_NormalMatrix*gl_Normal);
    bn=cross(tg,nm)*at_tangent.w;
    
    vec4 v=gbufferModelViewInverse*(gl_ModelViewMatrix*gl_Vertex);
    wp=v.xyz+cameraPosition;
    float t=frameTimeCounter;
    float h=wv(wp,t);
    v.y+=h;
    v.x+=(h-wv(wp+vec3(0.1,0,0),t))*WAVES*0.1;
    v.z+=(h-wv(wp+vec3(0,0,0.1),t))*WAVES*0.1;
    
    vp=(gbufferModelView*v).xyz;
    sp=shadowProjection*shadowModelView*v;
    sp.xy=shadowDist(sp.xy); sp.z*=SSCALE; sp=sp*0.5+0.5;
    gl_Position=gl_ProjectionMatrix*gbufferModelView*v;
}

#version 120
#include "common.glsl"
#include "shadow_sampling.glsl"
varying vec2 tc; varying vec2 lm; varying vec4 co;
varying vec3 nm; varying vec3 vp; varying vec3 wp;
varying vec4 sp; varying vec3 tg; varying vec3 bn;
uniform sampler2D texture; uniform sampler2D noisetex;
uniform vec3 sunPosition; uniform vec3 moonPosition;
uniform float frameTimeCounter; uniform float rainStrength; uniform int worldTime;

float ns(vec2 p) { return texture2D(noisetex, p/256.0).r; }

vec3 wNorm(vec3 w) {
    float t=frameTimeCounter*0.3, d=0.06;
    float h =ns(w.xz*0.8+vec2(t,t*0.5))*0.45+ns(w.xz*2.0-vec2(t*0.3,t*0.7))*0.28
            +ns(w.xz*5.0+vec2(t*0.15,-t*0.2))*0.17*WAVE_DETAIL;
    float hx=ns((w.xz+vec2(d,0))*0.8+vec2(t,t*0.5))*0.45+ns((w.xz+vec2(d,0))*2.0-vec2(t*0.3,t*0.7))*0.28
            +ns((w.xz+vec2(d,0))*5.0+vec2(t*0.15,-t*0.2))*0.17*WAVE_DETAIL;
    float hz=ns((w.xz+vec2(0,d))*0.8+vec2(t,t*0.5))*0.45+ns((w.xz+vec2(0,d))*2.0-vec2(t*0.3,t*0.7))*0.28
            +ns((w.xz+vec2(0,d))*5.0+vec2(t*0.15,-t*0.2))*0.17*WAVE_DETAIL;
    return normalize(vec3(h-hx, d*5.0, h-hz));
}

void main() {
    vec4 alb = texture2D(texture, tc) * co;
    float day = getDay(worldTime);
    float sunset = getSunset(worldTime);
    
    vec3 vd = normalize(-vp);
    vec3 fn = normalize(mat3(tg, bn, nm) * wNorm(wp));
    float fr = clamp(schlick(max(dot(vd, fn), 0.0), 0.02), 0.02, 0.8);
    
    // Base water color
    vec3 waterC = vec3(0.03, 0.15, 0.25);
    
    // Reflection color - approximates vanilla sky
    vec3 dayRef = vec3(0.35, 0.50, 0.75);
    vec3 nightRef = vec3(0.02, 0.03, 0.07) * NIGHT_AMB * 2.0;
    vec3 sunsetRef = vec3(0.6, 0.32, 0.12);
    vec3 refl = mix(nightRef, dayRef, day);
    refl = mix(refl, sunsetRef, sunset * SUNSET_STR);
    
    // Light direction
    vec3 ld;
    if (day > 0.01) ld = normalize(sunPosition);
    else ld = normalize(moonPosition);
    vec3 sc = sunTint(day, sunset);
    
    // Specular highlight
    float spc = pow(max(dot(fn, normalize(ld + vd)), 0.0), 180.0);
    vec3 spec = sc * spc * SPECULAR * mix(0.25, 1.8, day);
    
    float sh = shad(sp);
    
    // Caustics
    #if CAUSTICS == 1
    float ct = frameTimeCounter * 0.35;
    float caus = (sin(wp.x*3.0+ct)*cos(wp.z*2.5+ct*0.7)*0.5+0.5)*0.15;
    waterC += vec3(caus*0.1, caus*0.18, caus*0.06) * sh * mix(0.15, 1.0, day);
    #endif
    
    // Lighting on water
    waterC += torch(lm.x)*0.35 + skyAmb(lm.y, day)*0.25 + ambFloor(day);
    float wndl = max(dot(fn, ld), 0.0);
    waterC += sc * wndl * sh * SUN_STRENGTH * 0.2 * mix(0.25, 1.0, day);
    
    // Combine
    vec3 final = mix(waterC, refl, fr) + spec * sh;
    final *= mix(1.0, 0.6, rainStrength);
    
    float alpha = mix(WATER_ALPHA, 0.78, fr);
    alpha = clamp(alpha * mix(1.0, 1.15, rainStrength), 0.0, 0.9);
    
    gl_FragData[0] = vec4(final, alpha);
}

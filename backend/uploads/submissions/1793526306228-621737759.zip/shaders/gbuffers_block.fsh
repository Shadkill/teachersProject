#version 120
#include "common.glsl"
#include "shadow_sampling.glsl"
varying vec2 tc; varying vec2 lm; varying vec4 co;
varying vec3 nm; varying vec3 vp; varying vec4 sp;
uniform sampler2D texture;
uniform vec3 sunPosition; uniform vec3 moonPosition;
uniform int worldTime; uniform float rainStrength;
void main() {
    vec4 a=texture2D(texture,tc)*co; if(a.a<0.1)discard;
    float day=getDay(worldTime), sunset=getSunset(worldTime);
    vec3 ld; if(day>0.01)ld=normalize(sunPosition);else ld=normalize(moonPosition);
    float wrap=max((max(dot(nm,ld),0.0)+0.2)/1.2,0.0);
    vec3 sc=sunTint(day,sunset);
    vec3 light=sc*wrap*shad(sp)*SUN_STRENGTH*mix(0.35,1.0,day)
              +torch(lm.x)+skyAmb(lm.y,day)+ambFloor(day);
    light*=mix(1.0,0.5,rainStrength);
    gl_FragData[0]=vec4(a.rgb*light,a.a);
}

#version 120
#include "common.glsl"
varying vec2 tc; varying vec2 lm; varying vec4 co;
varying vec3 nm; varying vec3 vp; varying vec4 sp;
uniform mat4 gbufferModelView; uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView; uniform mat4 shadowProjection;
void main() {
    tc=(gl_TextureMatrix[0]*gl_MultiTexCoord0).xy;
    lm=(gl_TextureMatrix[1]*gl_MultiTexCoord1).xy;
    co=gl_Color; nm=normalize(gl_NormalMatrix*gl_Normal);
    vec4 v=gbufferModelViewInverse*(gl_ModelViewMatrix*gl_Vertex);
    vp=(gbufferModelView*v).xyz;
    sp=shadowProjection*shadowModelView*v;
    sp.xy=shadowDist(sp.xy); sp.z*=SSCALE; sp=sp*0.5+0.5;
    gl_Position=ftransform();
}
